```

**salida.php**
